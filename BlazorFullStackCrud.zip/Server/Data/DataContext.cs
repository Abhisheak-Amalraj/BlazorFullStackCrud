﻿namespace BlazorFullStackCrud.Server.Data
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) : base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>().HasData(
                        new User { ID = 1, firstname = "Abhisheak", surname = "Amalraj", email = "abhisheak.amalraj@gmail.com" },
            new User { ID = 2, firstname = "Priyanka", surname = "Nagrare", email = "nagrarepriyanka3@gmail.com" });
        }

        public DbSet<User> Users { get; set; }
    }
}
